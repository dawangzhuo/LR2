import csv
import json
from functools import lru_cache
from pathlib import Path
from statistics import mean

import httpx

root = Path(__file__).resolve().parent
results = root / "results"
budget = 1024
ks = (3,)

def read_jsonl(path):
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

instruction = (root / "prompts/rag.txt").read_text(encoding="utf-8-sig").strip()
documents = {
    str(row["doc_id"]): row
    for row in read_jsonl(root / "data/raw/corpus.jsonl")
}
retrieval = read_jsonl(results / "dev_top5.jsonl")
manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)
if len(retrieval) != 90 or {row["claim_id"] for row in retrieval} != set(manifest["dev_ids"]):
    raise SystemExit("Dev retrieval coverage: FAIL")

def messages_for(claim, context):
    return [
        {"role": "system", "content": instruction},
        {"role": "user", "content": f"Claim: {claim}\n\nDocuments:\n{context}"},
    ]

def post(client, endpoint, body):
    response = client.post(endpoint, json=body)
    if not response.is_success:
        raise RuntimeError(f"{endpoint}: HTTP {response.status_code}: {response.text[:300]}")
    return response.json()

def build_contexts(client, row):
    claim = row["claim"]
    ranking = row["retrieved"]

    # 同一陈述的三个 k 复用已经计算过的提示词长度。
    @lru_cache(maxsize=None)
    def render(context):
        prompt = post(client, "/apply-template", {
            "messages": messages_for(claim, context),
        })["prompt"]
        tokens = post(client, "/tokenize", {
            "content": prompt,
            "add_special": True,
            "parse_special": True,
        })["tokens"]
        return prompt, len(tokens)

    if render("")[1] > budget:
        raise RuntimeError("The instruction and claim exceed the input budget.")

    records = []
    for k in ks:
        context = ""
        transmitted = []
        for item in ranking[:k]:
            doc_id = str(item["doc_id"])
            doc = documents[doc_id]
            sentences = doc["abstract"]
            header = f"Document {doc_id}: {doc['title']}"
            lines = [f"[{i}] {sentence}" for i, sentence in enumerate(sentences)]
            base = context + ("\n\n" if context else "") + header
            full = "\n".join([base, *lines])

            # 整篇放不下时，只加入能容纳的连续完整句子。
            if render(full)[1] <= budget:
                context = full
                count = len(lines)
            else:
                partial = base
                count = 0
                for line in lines:
                    candidate = partial + "\n" + line
                    if render(candidate)[1] > budget:
                        break
                    partial = candidate
                    count += 1
                if count:
                    context = partial

            if count:
                transmitted.append({"doc_id": doc_id, "sentences": list(range(count))})
            if count < len(lines):
                break

        prompt, token_count = render(context)
        records.append({
            "claim_id": row["claim_id"],
            "k": k,
            "retrieved": ranking[:k],
            "transmitted": transmitted,
            "messages": messages_for(claim, context),
            "prompt": prompt,
            "prompt_tokens": token_count,
        })
    return records

def evidence_present(evidence, transmitted):
    # 同一文档中，至少一组标准证据的所有句子都已传入。
    included = {item["doc_id"]: set(item["sentences"]) for item in transmitted}
    return any(
        group["sentences"] and set(group["sentences"]) <= included.get(str(doc_id), set())
        for doc_id, groups in evidence.items()
        for group in groups
    )

example = {"42": [{"sentences": [1, 3]}]}
if (
    not evidence_present(example, [{"doc_id": "42", "sentences": [1, 3]}])
    or evidence_present(example, [{"doc_id": "42", "sentences": [1]}])
):
    raise SystemExit("Complete evidence check: FAIL")
print("Complete evidence check: PASS")

records = []
with httpx.Client(base_url="http://127.0.0.1:8080", timeout=30, trust_env=False) as client:
    for number, row in enumerate(retrieval, start=1):
        records.extend(build_contexts(client, row))
        if number % 15 == 0:
            print(f"Processed: {number}/90")

if len(records) != len(retrieval) * len(ks) or any(row["prompt_tokens"] > budget for row in records):
    raise SystemExit("Context budget validation: FAIL")

context_path = results / "dev_contexts_1024.jsonl"
with context_path.open("w", encoding="utf-8") as handle:
    for row in records:
        handle.write(json.dumps(row, ensure_ascii=False) + "\n")

# 上下文保存后才读取标准证据，并单独计算指标。
dev_ids = set(manifest["dev_ids"])
gold = {
    row["id"]: row["evidence"]
    for row in read_jsonl(root / "data/raw/claims_dev.jsonl")
    if row["id"] in dev_ids and row["evidence"]
}
if len(gold) != 60:
    raise SystemExit("Expected 60 claims with gold evidence.")

summary = []
print("k  Complete evidence  Mean docs  Mean tokens  Max tokens")
for k in ks:
    group = [row for row in records if row["k"] == k]
    hits = sum(
        evidence_present(gold[row["claim_id"]], row["transmitted"])
        for row in group
        if row["claim_id"] in gold
    )
    stats = {
        "k": k,
        "complete_evidence_count": hits,
        "evidence_claims": len(gold),
        "complete_evidence_rate": hits / len(gold),
        "mean_docs": mean(len(row["transmitted"]) for row in group),
        "mean_tokens": mean(row["prompt_tokens"] for row in group),
        "max_tokens": max(row["prompt_tokens"] for row in group),
    }
    summary.append(stats)
    print(f"{k}  {hits}/60 ({hits / 60:.2%})  "
          f"{stats['mean_docs']:.2f}  {stats['mean_tokens']:.1f}  {stats['max_tokens']}")

metrics_path = results / "context_metrics_1024.csv"
with metrics_path.open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
    writer.writeheader()
    writer.writerows(summary)

print("Saved:", context_path)
print("Saved:", metrics_path)
print("Context budget validation: PASS")
