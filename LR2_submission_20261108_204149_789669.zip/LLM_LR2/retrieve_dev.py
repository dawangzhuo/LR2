﻿import hashlib
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from sentence_transformers import SentenceTransformer

root = Path(__file__).resolve().parent
index_dir = root / "index"
manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)
passport = json.loads(
    (index_dir / "index_passport.json").read_text(encoding="utf-8")
)

# 检查索引和行号映射是否与构建时一致。
vectors_path = index_dir / passport["vectors_file"]
ids_path = index_dir / passport["doc_ids_file"]
for path, expected in (
    (vectors_path, passport["vectors_sha256"]),
    (ids_path, passport["doc_ids_sha256"]),
):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f"SHA-256 mismatch: {path.name}")

vectors = np.load(vectors_path, allow_pickle=False)
doc_ids = json.loads(ids_path.read_text(encoding="utf-8"))
if vectors.shape != (5183, 384) or len(doc_ids) != 5183:
    raise SystemExit("Index shape or document mapping: FAIL")
print("Index integrity: PASS")

# 只把固定 dev 划分中的陈述文本交给检索流程。
claims_path = root / "data/raw/claims_dev.jsonl"
claims_bytes = claims_path.read_bytes()
expected = manifest["files"]["claims_dev.jsonl"]["sha256"]
if hashlib.sha256(claims_bytes).hexdigest() != expected:
    raise SystemExit("Claims file SHA-256: FAIL")

dev_ids = manifest["dev_ids"]
if len(dev_ids) != 90 or len(set(dev_ids)) != 90:
    raise SystemExit("Dev split size: FAIL")
dev_set = set(dev_ids)
dev_texts = {}
for line in claims_bytes.splitlines():
    if line.strip():
        row = json.loads(line)
        if row["id"] in dev_set:
            dev_texts[row["id"]] = row["claim"]

if set(dev_texts) != dev_set:
    raise SystemExit("Dev claim IDs: FAIL")

# 从本地缓存加载构建索引时使用的同一个模型版本。
print("Loading cached encoder on CPU...")
model = SentenceTransformer(
    passport["model"],
    revision=passport["revision"],
    device="cpu",
    local_files_only=True,
)

output = root / "results/dev_top5.jsonl"
records = []
print("Retrieving Top 5 for 90 dev claims...")

for number, claim_id in enumerate(dev_ids, start=1):
    claim = dev_texts[claim_id]
    start = perf_counter()
    query = model.encode(
        passport["query_prefix"] + claim,
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=False,
    )

    # 向量已归一化，点积就是余弦相似度。同分时沿用语料行顺序。
    scores = vectors @ query
    if not np.isfinite(scores).all():
        raise SystemExit(f"Non-finite similarity scores for claim {claim_id}")
    top_rows = np.argsort(-scores, kind="stable")[:5]
    ranking = [
        {"rank": rank, "doc_id": doc_ids[i], "score": float(scores[i])}
        for rank, i in enumerate(top_rows, start=1)
    ]
    records.append({
        "claim_id": claim_id,
        "claim": claim,
        "retrieved": ranking,
        "search_ms": round((perf_counter() - start) * 1000, 3),
    })
    if number % 30 == 0:
        print(f"Processed: {number}/90")

with output.open("w", encoding="utf-8") as handle:
    for record in records:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")

print("Dev claims:", len(records))
print("Retrieved documents per claim: 5")
print("Results saved:", output.resolve())
print("Dev retrieval: PASS")
