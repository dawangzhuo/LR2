﻿import json
from pathlib import Path

import httpx
from jsonschema import validate

root = Path.cwd()
schema = {
    "type": "object",
    "additionalProperties": False,
    "required": ["label", "doc_id", "sentences"],
    "properties": {
        "label": {"enum": ["SUPPORT", "CONTRADICT", "NOINFO"]},
        "doc_id": {"anyOf": [{"type": "string"}, {"type": "null"}]},
        "sentences": {"type": "array", "items": {"type": "integer"}},
    },
}
response_format = {
    "type": "json_schema",
    "json_schema": {"name": "verdict", "strict": True, "schema": schema},
}

with (root / "data/raw/claims_train.jsonl").open(encoding="utf-8") as file:
    claim = next(json.loads(line) for line in file if line.strip())

instruction = (root / "prompts/rag.txt").read_text(encoding="utf-8-sig").strip()
# 空文档列表用于测试接口和 NOINFO 的输出格式。
messages = [
    {"role": "system", "content": instruction},
    {"role": "user", "content": f"Claim: {claim['claim']}\n\nDocuments:\n"},
]

def post(client, path, payload):
    response = client.post(path, json=payload)
    if not response.is_success:
        raise SystemExit(f"{path}: HTTP {response.status_code}: {response.text}")
    return response.json()

with httpx.Client(base_url="http://127.0.0.1:8080", timeout=60, trust_env=False) as client:
    models = client.get("/v1/models")
    models.raise_for_status()
    model_id = models.json()["data"][0]["id"]
    prompt = post(client, "/apply-template", {"messages": messages})["prompt"]
    tokens = post(client, "/tokenize", {
        "content": prompt,
        "add_special": True,
        "parse_special": True,
    })["tokens"]
    response = post(client, "/v1/chat/completions", {
        "model": model_id,
        "messages": messages,
        "response_format": response_format,
        "temperature": 0,
        "max_tokens": 128,
    })

raw = response["choices"][0]["message"]["content"]
actual_tokens = response["usage"]["prompt_tokens"]
record = {
    "split": "train",
    "claim_id": claim["id"],
    "model": model_id,
    "messages": messages,
    "rendered_prompt": prompt,
    "calculated_prompt_tokens": len(tokens),
    "server_prompt_tokens": actual_tokens,
    "response": response,
}
(root / "logs/lr2_schema_smoke_test.json").write_text(
    json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)

print("Model:", model_id)
print("Raw answer:", raw)
print("Calculated prompt tokens:", len(tokens))
print("Server prompt tokens:", actual_tokens)

answer = json.loads(raw)
validate(answer, schema)
print("JSON Schema validation: PASS")

if answer != {"label": "NOINFO", "doc_id": None, "sentences": []}:
    raise SystemExit("Empty-context verdict: FAIL")
print("Empty-context verdict: PASS")

if len(tokens) != actual_tokens:
    raise SystemExit("Prompt token agreement: FAIL")
print("Prompt token agreement: PASS")

(root / "schemas/response_format.json").write_text(
    json.dumps(response_format, indent=2) + "\n", encoding="utf-8"
)
print("Smoke test: PASS")
