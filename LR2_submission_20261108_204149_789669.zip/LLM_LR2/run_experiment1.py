﻿import json
from pathlib import Path
from time import perf_counter

import httpx
from jsonschema import ValidationError
from sentence_transformers import SentenceTransformer

from answer_parser import parse_answer, response_format

root = Path(__file__).resolve().parent
results = root / "results"
run_dir = results / "experiment1"
output = run_dir / "results.jsonl"


def read_jsonl(path):
    with path.open(encoding="utf-8-sig") as file:
        return [json.loads(line) for line in file if line.strip()]


def messages_for(instruction, text):
    return [
        {"role": "system", "content": instruction},
        {"role": "user", "content": text},
    ]


def post(client, path, payload):
    response = client.post(path, json=payload)
    response.raise_for_status()
    return response.json()


def count_tokens(client, messages):
    prompt = post(client, "/apply-template", {"messages": messages})["prompt"]
    return len(post(client, "/tokenize", {
        "content": prompt,
        "add_special": True,
        "parse_special": True,
    })["tokens"])


if not (root / "prediction.md").is_file():
    raise SystemExit("Save prediction.md before formal generation.")

manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)
dev_ids = set(manifest["dev_ids"])
claims = {
    row["id"]: row
    for row in read_jsonl(root / "data/raw/claims_dev.jsonl")
    if row["id"] in dev_ids
}
documents = {
    str(row["doc_id"]): row
    for row in read_jsonl(root / "data/raw/corpus.jsonl")
}
contexts = [
    row for row in read_jsonl(results / "dev_contexts_2048.jsonl")
    if row["k"] == 3
]
if len(contexts) != 90 or {row["claim_id"] for row in contexts} != dev_ids:
    raise SystemExit("RAG k=3 context coverage: FAIL")

baseline_instruction = (
    "Judge the scientific claim using your own knowledge. "
    "Use SUPPORT if the claim is supported, CONTRADICT if it is refuted, "
    "and NOINFO if you cannot determine the answer. "
    "Return one JSON object with label, doc_id, and sentences. "
    "Always use null for doc_id and [] for sentences."
)
rag_instruction = (root / "prompts/rag.txt").read_text(encoding="utf-8-sig").strip()

# 为三种模式准备输入。标准证据仅用于 Oracle 输入。
jobs = []
for row in contexts:
    claim_id = row["claim_id"]
    claim = claims[claim_id]
    text = f"Claim: {claim['claim']}"

    jobs.append({
        "claim_id": claim_id,
        "mode": "llm_only",
        "k": None,
        "messages": messages_for(baseline_instruction, text),
        "transmitted": [],
        "retrieved": [],
    })
    jobs.append({**row, "mode": "rag"})

    if claim["evidence"]:
        doc_id = min(claim["evidence"], key=int)
        group = claim["evidence"][doc_id][0]
        sentence_ids = sorted(set(group["sentences"]))
        doc = documents[doc_id]
        lines = [f"Document {doc_id}: {doc['title']}"]
        lines.extend(f"[{i}] {doc['abstract'][i]}" for i in sentence_ids)
        context = "\n".join(lines)
        jobs.append({
            "claim_id": claim_id,
            "mode": "oracle",
            "k": None,
            "messages": messages_for(rag_instruction, f"{text}\n\nDocuments:\n{context}"),
            "transmitted": [{"doc_id": doc_id, "sentences": sentence_ids}],
            "retrieved": [],
        })

if len(jobs) != 240:
    raise SystemExit(f"Expected 240 jobs, found {len(jobs)}.")

run_dir.mkdir(parents=True, exist_ok=True)
(root / "prompts/llm_only.txt").write_text(baseline_instruction + "\n", encoding="utf-8")

# 从本地缓存加载索引使用的编码器，记录同文本的查询与文档相似度。
passport = json.loads((root / "index/index_passport.json").read_text(encoding="utf-8"))
encoder = SentenceTransformer(
    passport["model"], revision=passport["revision"],
    device="cpu", local_files_only=True,
)
sample = "Exercise improves cardiovascular health."
query, document = encoder.encode(
    [passport["query_prefix"] + sample, sample],
    normalize_embeddings=True,
    show_progress_bar=False,
)
similarity = float(query @ document)
print(f"Same-text query/document cosine: {similarity:.4f}")
(run_dir / "encoder_check.json").write_text(
    json.dumps({"text": sample, "cosine_similarity": similarity}, indent=2) + "\n",
    encoding="utf-8",
)
del encoder

# 续跑时跳过已经写入的记录，包括已记录的失败。
existing = read_jsonl(output) if output.exists() else []
done = {(row["mode"], row["claim_id"]) for row in existing}
expected = {(job["mode"], job["claim_id"]) for job in jobs}
if len(done) != len(existing) or not done <= expected:
    raise SystemExit("Existing results contain unexpected or duplicate records.")

with httpx.Client(
    base_url="http://127.0.0.1:8080",
    timeout=httpx.Timeout(120.0, connect=10.0),
    trust_env=False,
) as client:
    models = client.get("/v1/models")
    models.raise_for_status()
    model_id = models.json()["data"][0]["id"]
    if any(row["model"] != model_id for row in existing):
        raise SystemExit("Model differs from the existing run.")

    print(f"Experiment 1: {len(done)}/240 already recorded")
    with output.open("a", encoding="utf-8") as file:
        for job in jobs:
            key = (job["mode"], job["claim_id"])
            if key in done:
                continue

            record = {
                **job,
                "model": model_id,
                "status": "ok",
                "raw_answer": None,
                "answer": None,
            }
            started = perf_counter()
            try:
                tokens = job.get("prompt_tokens")
                if tokens is None:
                    tokens = count_tokens(client, job["messages"])
                record["prompt_tokens"] = tokens
                if tokens > 2048:
                    raise ValueError(f"Input budget exceeded: {tokens}")

                response = post(client, "/v1/chat/completions", {
                    "model": model_id,
                    "messages": job["messages"],
                    "response_format": response_format,
                    "temperature": 0,
                    "max_tokens": 128,
                    "stream": False,
                })
                record["response"] = response
                choice = response["choices"][0]
                raw = choice["message"]["content"]
                record["raw_answer"] = raw
                actual = response["usage"]["prompt_tokens"]
                record["server_prompt_tokens"] = actual
                if actual != tokens:
                    raise ValueError(f"Prompt token mismatch: {tokens} vs {actual}")
                if choice.get("finish_reason") == "length":
                    raise ValueError("Output reached the token limit.")

                record["answer"] = parse_answer(raw, job["mode"], job["transmitted"])
            except (httpx.HTTPError, ValueError, ValidationError, KeyError, IndexError, TypeError) as exc:
                record["status"] = "error"
                record["error"] = f"{type(exc).__name__}: {exc}"

            record["elapsed_seconds"] = round(perf_counter() - started, 3)
            file.write(json.dumps(record, ensure_ascii=False) + "\n")
            file.flush()
            done.add(key)
            print(f"[{len(done)}/240] {job['mode']} {job['claim_id']}: {record['status']}")

records = read_jsonl(output)
for mode in ("llm_only", "rag", "oracle"):
    group = [row for row in records if row["mode"] == mode]
    errors = sum(row["status"] != "ok" for row in group)
    print(f"{mode}: {len(group)} records, {errors} errors")
print("Results saved:", output)
print("Experiment 1 recording complete.")
