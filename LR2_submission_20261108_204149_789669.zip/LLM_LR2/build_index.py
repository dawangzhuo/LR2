﻿import hashlib
import json
from pathlib import Path

import numpy as np
from huggingface_hub import HfApi
from sentence_transformers import SentenceTransformer

root = Path(__file__).resolve().parent
corpus_path = root / "data" / "raw" / "corpus.jsonl"
manifest_path = root / "data" / "processed" / "scifact_manifest.json"
index_dir = root / "index"
model_id = "BAAI/bge-small-en-v1.5"
query_prefix = "Represent this sentence for searching relevant passages: "

# 先确认本次使用的是已经校验过的语料。
corpus_bytes = corpus_path.read_bytes()
corpus_sha256 = hashlib.sha256(corpus_bytes).hexdigest()
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
if corpus_sha256 != manifest["files"]["corpus.jsonl"]["sha256"]:
    raise SystemExit("Corpus SHA-256: FAIL")

documents = [json.loads(line) for line in corpus_bytes.splitlines() if line.strip()]
doc_ids = [str(doc["doc_id"]) for doc in documents]
if len(documents) != 5183 or len(set(doc_ids)) != 5183:
    raise SystemExit("Corpus count or unique document IDs: FAIL")
texts = [doc["title"] + "\n" + " ".join(doc["abstract"]) for doc in documents]
print("Corpus verification: PASS")

# 先取得模型的确切修订号，再按这个版本加载。
print("Resolving encoder revision...")
revision = HfApi().model_info(model_id).sha
if not revision:
    raise SystemExit("Encoder revision is unavailable.")
print("Encoder revision:", revision)
print("Loading encoder on CPU...")
model = SentenceTransformer(model_id, revision=revision, device="cpu")
max_tokens = model.max_seq_length
if max_tokens != 512:
    raise SystemExit(f"Unexpected encoder input limit: {max_tokens}")

# 统计截断比例时，先计算加入特殊 token 后的完整长度。
print("Counting documents above the encoder token limit...")
truncated = 0
for start in range(0, len(texts), 128):
    batch = model.tokenizer(
        texts[start:start + 128],
        add_special_tokens=True,
        truncation=False,
        return_length=True,
        verbose=False,
    )
    truncated += sum(length > max_tokens for length in batch["length"])

print("Encoding documents on CPU...")
vectors = model.encode(
    texts,
    batch_size=16,
    show_progress_bar=True,
    normalize_embeddings=True,
    convert_to_numpy=True,
).astype(np.float32, copy=False)

# 检查行数、向量维度和归一化，再写入索引文件。
if vectors.shape != (5183, 384) or not np.isfinite(vectors).all():
    raise SystemExit("Vector shape or values: FAIL")
if not np.allclose(np.linalg.norm(vectors, axis=1), 1.0, atol=1e-4):
    raise SystemExit("Vector normalization: FAIL")

index_dir.mkdir(parents=True, exist_ok=True)
vector_path = index_dir / "corpus_embeddings.npy"
ids_path = index_dir / "doc_ids.json"
passport_path = index_dir / "index_passport.json"

np.save(vector_path, vectors, allow_pickle=False)
ids_path.write_text(json.dumps(doc_ids, indent=2) + "\n", encoding="utf-8")
passport = {
    "model": model_id,
    "revision": revision,
    "device": "cpu",
    "documents": len(doc_ids),
    "dimensions": vectors.shape[1],
    "dtype": str(vectors.dtype),
    "max_input_tokens": max_tokens,
    "normalize_embeddings": True,
    "query_prefix": query_prefix,
    "document_prefix": "",
    "document_format": "title + newline + abstract sentences joined by spaces",
    "truncated_documents": truncated,
    "truncated_fraction": truncated / len(doc_ids),
    "corpus_sha256": corpus_sha256,
    "vectors_file": vector_path.name,
    "vectors_sha256": hashlib.sha256(vector_path.read_bytes()).hexdigest(),
    "doc_ids_file": ids_path.name,
    "doc_ids_sha256": hashlib.sha256(ids_path.read_bytes()).hexdigest(),
}
passport_path.write_text(json.dumps(passport, indent=2) + "\n", encoding="utf-8")

print("Vector shape:", vectors.shape)
print(f"Truncated documents: {truncated}/{len(doc_ids)} ({truncated / len(doc_ids):.2%})")
print("Vector SHA-256:", passport["vectors_sha256"])
print("Index passport saved:", passport_path.resolve())
print("Index build: PASS")
