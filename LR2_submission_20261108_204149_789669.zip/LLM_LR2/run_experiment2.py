﻿import json
from pathlib import Path
from time import perf_counter

import httpx
from jsonschema import ValidationError

from answer_parser import parse_answer, response_format

root = Path(__file__).resolve().parent
run_dir = root / "results/experiment2"
output = run_dir / "results.jsonl"


def read_jsonl(path):
    with path.open(encoding="utf-8-sig") as file:
        return [json.loads(line) for line in file if line.strip()]


def job_key(row):
    return row["k"], row["claim_id"]


manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)
contexts = read_jsonl(root / "results/dev_contexts_2048.jsonl")
jobs = [row for row in contexts if row["k"] in (1, 5)]
expected = {(k, cid) for k in (1, 5) for cid in manifest["dev_ids"]}

if len(expected) != 180 or len(jobs) != 180 or {job_key(row) for row in jobs} != expected:
    raise SystemExit("Experiment 2 context coverage: FAIL")
if any(not 0 < row["prompt_tokens"] <= 2048 for row in jobs):
    raise SystemExit("Experiment 2 input budget: FAIL")

# 保留已有记录。续跑时按 k 和陈述 ID 跳过已完成的任务。
run_dir.mkdir(parents=True, exist_ok=True)
existing = read_jsonl(output) if output.exists() else []
done = {job_key(row) for row in existing}
if len(done) != len(existing) or not done <= expected:
    raise SystemExit("Existing records contain duplicate or unexpected jobs.")

with httpx.Client(
    base_url="http://127.0.0.1:8080",
    timeout=httpx.Timeout(120.0, connect=10.0),
    trust_env=False,
) as client:
    models = client.get("/v1/models")
    models.raise_for_status()
    model_id = models.json()["data"][0]["id"]

    baseline = read_jsonl(root / "results/experiment1/results.jsonl")
    if {row["model"] for row in baseline} != {model_id}:
        raise SystemExit("Server model differs from Experiment 1.")
    if any(row["model"] != model_id for row in existing):
        raise SystemExit("Server model differs from existing Experiment 2 records.")

    print(f"Experiment 2: {len(done)}/180 already recorded")
    with output.open("a", encoding="utf-8") as file:
        for job in jobs:
            key = job_key(job)
            if key in done:
                continue

            record = {
                **job,
                "mode": "rag",
                "model": model_id,
                "status": "ok",
                "raw_answer": None,
                "answer": None,
            }
            started = perf_counter()

            try:
                response = client.post("/v1/chat/completions", json={
                    "model": model_id,
                    "messages": job["messages"],
                    "response_format": response_format,
                    "temperature": 0,
                    "max_tokens": 128,
                    "stream": False,
                })
                if not response.is_success:
                    record["http_response_body"] = response.text
                response.raise_for_status()
                payload = response.json()
                record["response"] = payload

                choice = payload["choices"][0]
                raw = choice["message"]["content"]
                record["raw_answer"] = raw
                actual = payload["usage"]["prompt_tokens"]
                record["server_prompt_tokens"] = actual
                if actual != job["prompt_tokens"]:
                    raise ValueError(f"Prompt token mismatch: {job['prompt_tokens']} vs {actual}")
                if choice.get("finish_reason") == "length":
                    raise ValueError("Output reached the token limit.")
                record["answer"] = parse_answer(raw, "rag", job["transmitted"])
            except (httpx.HTTPError, ValueError, ValidationError, KeyError, IndexError, TypeError) as exc:
                record["status"] = "error"
                record["error"] = f"{type(exc).__name__}: {exc}"

            # 每条立即保存，调用或解析失败也保留，供后续评分。
            record["elapsed_seconds"] = round(perf_counter() - started, 3)
            file.write(json.dumps(record, ensure_ascii=False) + "\n")
            file.flush()
            done.add(key)
            print(f"[{len(done)}/180] k={job['k']} claim={job['claim_id']}: {record['status']}")

records = read_jsonl(output)
if len(records) != 180 or {job_key(row) for row in records} != expected:
    raise SystemExit("Experiment 2 record coverage: FAIL")

for k in (1, 5):
    group = [row for row in records if row["k"] == k]
    errors = sum(row["status"] != "ok" for row in group)
    print(f"k={k}: {len(group)} records, {errors} errors")
print("Results saved:", output)
print("Experiment 2 record coverage: PASS")
