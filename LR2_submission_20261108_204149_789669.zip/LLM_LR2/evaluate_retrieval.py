﻿import csv
import hashlib
import json
from pathlib import Path
from statistics import mean

root = Path(__file__).resolve().parent
results = root / "results"
manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)

def score_at_k(ranking, gold_docs, k):
    # 按文档 ID 比较，取同一份排名的前 k 项。
    ranks = [
        rank for rank, doc_id in enumerate(ranking[:k], start=1)
        if doc_id in gold_docs
    ]
    return (
        int(bool(ranks)),
        len(ranks) / len(gold_docs),
        1 / ranks[0] if ranks else 0.0,
    )

# 作业给出的例子：两个相关文档，只有一个排在第三位。
example = ["a", "b", "c"]
if (
    score_at_k(example, {"c", "d"}, 3) != (1, 0.5, 1 / 3)
    or score_at_k(example, {"c", "d"}, 1) != (0, 0, 0)
):
    raise SystemExit("Metric example: FAIL")
print("Metric example: PASS")

# 在评估阶段读取标准证据，检索排名已提前保存。
claims_path = root / "data/raw/claims_dev.jsonl"
claims_bytes = claims_path.read_bytes()
if hashlib.sha256(claims_bytes).hexdigest() != manifest["files"]["claims_dev.jsonl"]["sha256"]:
    raise SystemExit("Claims SHA-256: FAIL")

dev_ids = set(manifest["dev_ids"])
claims = {}
for line in claims_bytes.splitlines():
    if line.strip():
        row = json.loads(line)
        if row["id"] in dev_ids:
            claims[row["id"]] = row

with (results / "dev_top5.jsonl").open(encoding="utf-8") as handle:
    retrieval = [json.loads(line) for line in handle if line.strip()]

if len(retrieval) != 90 or len(dev_ids) != 90 or set(claims) != dev_ids:
    raise SystemExit("Dev split coverage: FAIL")
if {row["claim_id"] for row in retrieval} != dev_ids:
    raise SystemExit("Retrieval claim IDs: FAIL")

details = []
evaluated = 0
for row in retrieval:
    claim_id = row["claim_id"]
    ranked = row["retrieved"]
    ranking = [str(item["doc_id"]) for item in ranked]
    if (
        row["claim"] != claims[claim_id]["claim"]
        or [item["rank"] for item in ranked] != [1, 2, 3, 4, 5]
        or len(set(ranking)) != 5
    ):
        raise SystemExit(f"Invalid retrieval record for claim {claim_id}")

    gold_docs = {
        str(doc_id) for doc_id, evidence in claims[claim_id]["evidence"].items()
        if evidence
    }
    if not gold_docs:
        continue

    evaluated += 1
    for k in (1, 3, 5):
        hit, recall, rr = score_at_k(ranking, gold_docs, k)
        details.append({
            "claim_id": claim_id,
            "k": k,
            "hit": hit,
            "recall": recall,
            "rr": rr,
        })

if evaluated != 60:
    raise SystemExit(f"Expected 60 evidence-bearing claims, found {evaluated}.")

summary = []
print(f"Claims with gold evidence: {evaluated}")
print(f"NOINFO excluded from retrieval metrics: {len(retrieval) - evaluated}")
print("k  Hit@k     Recall@k  MRR@k")
for k in (1, 3, 5):
    group = [row for row in details if row["k"] == k]
    hit = mean(row["hit"] for row in group)
    recall = mean(row["recall"] for row in group)
    mrr = mean(row["rr"] for row in group)
    summary.append({
        "k": k, "claims": len(group), "hit_at_k": hit,
        "recall_at_k": recall, "mrr_at_k": mrr,
    })
    print(f"{k}  {hit:.4f}    {recall:.4f}    {mrr:.4f}")

for name, rows in (
    ("retrieval_metrics.csv", summary),
    ("retrieval_per_claim.csv", details),
):
    with (results / name).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print("Saved:", results / name)

print("Retrieval evaluation: PASS")
