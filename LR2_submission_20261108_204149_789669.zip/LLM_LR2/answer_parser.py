﻿import json
from pathlib import Path

from jsonschema import Draft202012Validator

root = Path(__file__).resolve().parent
response_format = json.loads(
    (root / "schemas/response_format.json").read_text(encoding="utf-8-sig")
)
validator = Draft202012Validator(response_format["json_schema"]["schema"])


def parse_answer(raw, mode, transmitted=()):
    answer = json.loads(raw)
    validator.validate(answer)
    label = answer["label"]
    doc_id = answer["doc_id"]
    sentences = answer["sentences"]

    # 无证据答案与无检索基线都使用空引用。
    if label == "NOINFO" or mode == "llm_only":
        if doc_id is not None or sentences:
            raise ValueError("Expected null doc_id and an empty sentence list.")
        return answer

    # RAG 和 Oracle 只能引用实际传入的文档及句子。
    allowed = {
        str(document["doc_id"]): set(document["sentences"])
        for document in transmitted
    }
    if doc_id not in allowed or not sentences:
        raise ValueError("Expected a transmitted document and at least one sentence.")
    if any(type(number) is not int or number not in allowed[doc_id] for number in sentences):
        raise ValueError("Citation contains a sentence not supplied to the model.")
    return answer


if __name__ == "__main__":
    from jsonschema import ValidationError

    supplied = [{"doc_id": "42", "sentences": [0, 2]}]
    valid = {"label": "SUPPORT", "doc_id": "42", "sentences": [2]}
    if parse_answer(json.dumps(valid), "rag", supplied) != valid:
        raise SystemExit("Valid citation: FAIL")
    print("Valid citation: PASS")

    cases = [
        ("Unknown label", {**valid, "label": "UNKNOWN"}, ValidationError),
        ("Extra field", {**valid, "extra": True}, ValidationError),
        ("Unseen sentence", {**valid, "sentences": [1]}, ValueError),
    ]
    for name, answer, expected_error in cases:
        try:
            parse_answer(json.dumps(answer), "rag", supplied)
        except expected_error:
            print(f"{name}: PASS")
        else:
            raise SystemExit(f"{name}: FAIL")

    print("Answer parser checks: PASS")
