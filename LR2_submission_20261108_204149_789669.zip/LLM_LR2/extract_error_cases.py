﻿import json
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent
results = root / "results"


def read_jsonl(path):
    with path.open(encoding="utf-8-sig") as file:
        return [json.loads(line) for line in file if line.strip()]


manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)
dev_ids = set(manifest["dev_ids"])
claims = {
    row["id"]: row
    for row in read_jsonl(root / "data/raw/claims_dev.jsonl")
    if row["id"] in dev_ids
}
documents = {
    str(row["doc_id"]): row
    for row in read_jsonl(root / "data/raw/corpus.jsonl")
}
records = [
    row
    for folder in ("experiment1", "experiment2")
    for row in read_jsonl(results / folder / "results.jsonl")
    if row["mode"] == "rag"
]
keys = {(row["k"], row["claim_id"]) for row in records}
expected = {(k, cid) for k in (1, 3, 5) for cid in dev_ids}
if len(dev_ids) != 90 or len(records) != 270 or keys != expected:
    raise SystemExit("RAG record coverage: FAIL")

categories = (
    "retrieval_miss",
    "evidence_not_in_context",
    "wrong_label_with_evidence",
    "noinfo_wrong",
    "invalid_citation",
)
examples = {}
counts = Counter()

# 优先从 k=3 选例，再查看 k=1 和 k=5。
for row in sorted(records, key=lambda r: ({3: 0, 1: 1, 5: 2}[r["k"]], r["claim_id"])):
    cid = row["claim_id"]
    claim = claims[cid]
    evidence = claim["evidence"]
    gold_label = (
        next(group["label"] for groups in evidence.values() for group in groups)
        if evidence else "NOINFO"
    )
    ranked_ids = {str(item["doc_id"]) for item in row["retrieved"]}
    included = {
        str(item["doc_id"]): set(item["sentences"])
        for item in row["transmitted"]
    }
    hit = bool(ranked_ids.intersection(evidence))
    complete = any(
        group["sentences"] and set(group["sentences"]) <= included.get(doc_id, set())
        for doc_id, groups in evidence.items()
        for group in groups
    )

    answer = row.get("answer") or {}
    wrong_label = row["status"] == "ok" and answer.get("label") != gold_label
    error = row.get("error", "")
    if evidence and hit and not complete:
        counts["evidence_not_in_context_all_records"] += 1

    if wrong_label and evidence and not hit:
        category = "retrieval_miss"
    elif wrong_label and evidence and hit and not complete:
        category = "evidence_not_in_context"
    elif wrong_label and complete:
        category = "wrong_label_with_evidence"
    elif wrong_label and not evidence:
        category = "noinfo_wrong"
    elif row["status"] != "ok" and "Citation contains a sentence" in error:
        category = "invalid_citation"
    else:
        continue

    counts[category] += 1
    if category in examples:
        continue

    # 保留实际传入的句子原文和编号，供报告与答辩核对。
    transmitted = []
    for item in row["transmitted"]:
        doc_id = str(item["doc_id"])
        doc = documents[doc_id]
        transmitted.append({
            "doc_id": doc_id,
            "title": doc["title"],
            "sentences": [
                {"index": i, "text": doc["abstract"][i]}
                for i in item["sentences"]
            ],
        })
    examples[category] = {
        "category": category,
        "k": row["k"],
        "claim_id": cid,
        "claim": claim["claim"],
        "gold_label": gold_label,
        "gold_evidence": evidence,
        "retrieved": row["retrieved"],
        "transmitted": transmitted,
        "complete_evidence": complete,
        "raw_answer": row.get("raw_answer"),
        "error": error,
    }

output = results / "lr2_error_cases.json"
output.write_text(
    json.dumps({"counts": dict(counts), "examples": examples},
               ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)

print("Retrieved gold document but incomplete evidence:",
      counts["evidence_not_in_context_all_records"])
for category in categories:
    example = examples.get(category)
    if example:
        print(f"{category}: {counts[category]} records")
        print(f"  k={example['k']}, claim={example['claim_id']}, gold={example['gold_label']}")
        print("  Claim:", example["claim"])
        print("  Raw answer:", json.dumps(example["raw_answer"], ensure_ascii=False))
        if example["error"]:
            print("  Error:", example["error"])
    else:
        print(f"{category}: 0 records")

print("Saved:", output)
print("Error case extraction: PASS")
