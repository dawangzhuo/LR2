﻿import csv
import json
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent
results = root / "results"
run = results / "experiment2"
ks = (1, 3, 5)


def read_jsonl(path):
    with path.open(encoding="utf-8-sig") as file:
        return [json.loads(line) for line in file if line.strip()]


def save_csv(name, rows):
    with (run / name).open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)
ids = manifest["dev_ids"]
dev = set(ids)

gold = {}
for row in read_jsonl(root / "data/raw/claims_dev.jsonl"):
    if row["id"] not in dev:
        continue
    evidence = row["evidence"]
    labels = {group["label"] for groups in evidence.values() for group in groups}
    if evidence and (len(labels) != 1 or not labels <= {"SUPPORT", "CONTRADICT"}):
        raise SystemExit(f"Invalid gold evidence for claim {row['id']}")
    gold[row["id"]] = (next(iter(labels)) if evidence else "NOINFO", evidence)

if len(ids) != 90 or len(dev) != 90 or set(gold) != dev:
    raise SystemExit("Gold dev coverage: FAIL")
if Counter(label for label, _ in gold.values()) != {
    "SUPPORT": 30, "CONTRADICT": 30, "NOINFO": 30
}:
    raise SystemExit("Gold label balance: FAIL")

# 从实验 1 取 k=3，从实验 2 取 k=1 和 k=5。
k3 = [
    row for row in read_jsonl(results / "experiment1/results.jsonl")
    if row["mode"] == "rag" and row["k"] == 3
]
new = read_jsonl(run / "results.jsonl")
records = k3 + new
by_key = {(row["k"], row["claim_id"]): row for row in records}
expected = {(k, cid) for k in ks for cid in ids}

if len(k3) != 90 or len(new) != 180 or len(records) != len(by_key) or set(by_key) != expected:
    raise SystemExit("Paired record coverage: FAIL")
if any(row["mode"] != "rag" for row in records) or len({row["model"] for row in records}) != 1:
    raise SystemExit("Mode or model consistency: FAIL")
print("Paired record coverage: PASS")

# 合并前面已计算的检索指标和上下文指标。
def read_by_k(name):
    with (results / name).open(encoding="utf-8-sig", newline="") as file:
        return {int(row["k"]): row for row in csv.DictReader(file)}


retrieval = read_by_k("retrieval_metrics.csv")
context = read_by_k("context_metrics_2048.csv")
evidence_ids = [cid for cid in ids if gold[cid][0] != "NOINFO"]


def label_correct(k, cid):
    row = by_key[k, cid]
    return row["status"] == "ok" and row["answer"]["label"] == gold[cid][0]


def citation_correct(k, cid):
    # 正确引用需要标签正确，并引用同一文档中的至少一组完整标准证据。
    if not label_correct(k, cid):
        return False
    answer = by_key[k, cid]["answer"]
    cited = set(answer["sentences"])
    groups = gold[cid][1].get(answer["doc_id"], [])
    return any(group["sentences"] and set(group["sentences"]) <= cited for group in groups)


summary = []
print("k  Accuracy          Correct citations  Complete evidence  Mean docs  Mean tokens")
for k in ks:
    correct = sum(label_correct(k, cid) for cid in ids)
    citations = sum(citation_correct(k, cid) for cid in evidence_ids)
    ctx = context[k]
    row = {
        "k": k,
        "correct_labels": correct,
        "accuracy": correct / 90,
        "correct_citations": citations,
        "correct_citation_rate": citations / 60,
        "errors": sum(by_key[k, cid]["status"] != "ok" for cid in ids),
        "hit_at_k": retrieval[k]["hit_at_k"],
        "recall_at_k": retrieval[k]["recall_at_k"],
        "mrr_at_k": retrieval[k]["mrr_at_k"],
        "complete_evidence_count": ctx["complete_evidence_count"],
        "complete_evidence_rate": ctx["complete_evidence_rate"],
        "mean_docs": ctx["mean_docs"],
        "mean_tokens": ctx["mean_tokens"],
        "max_tokens": ctx["max_tokens"],
    }
    summary.append(row)
    print(
        f"{k}  {correct}/90 ({correct / 90:.2%})  "
        f"{citations}/60 ({citations / 60:.2%})  "
        f"{ctx['complete_evidence_count']}/60  "
        f"{float(ctx['mean_docs']):.2f}  {float(ctx['mean_tokens']):.1f}"
    )

pairs = []
for before, after in ((1, 3), (3, 5)):
    counts = Counter()
    for cid in ids:
        transition = {
            (False, True): "fixed",
            (True, False): "regressed",
            (True, True): "both_correct",
            (False, False): "both_wrong",
        }[label_correct(before, cid), label_correct(after, cid)]
        counts[transition] += 1
        pairs.append({
            "claim_id": cid,
            "gold_label": gold[cid][0],
            "from_k": before,
            "to_k": after,
            "transition": transition,
        })
    print(
        f"k={before} -> k={after}: fixed={counts['fixed']}, "
        f"regressed={counts['regressed']}, both_correct={counts['both_correct']}, "
        f"both_wrong={counts['both_wrong']}"
    )

for row in new:
    if row["status"] != "ok":
        print(f"Recorded error: k={row['k']} claim={row['claim_id']} {row.get('error', '')}")

save_csv("metrics_by_k.csv", summary)
save_csv("paired_transitions_by_k.csv", pairs)
print("Experiment 2 evaluation: PASS")
