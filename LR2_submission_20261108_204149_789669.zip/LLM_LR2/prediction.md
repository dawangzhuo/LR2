﻿# LR2 predictions
Recorded at: 2026-11-08T19:43:29.8279089+07:00
Stage: after retrieval and context evaluation, before model generation.

- I expect LLM-only to make the most errors on NOINFO because it has no corpus context to judge whether evidence is available.
- On 90 dev claims, I predict that RAG at k=3 will fix about 15 LLM-only errors and turn about 5 correct answers into errors.
- I predict that RAG accuracy will rise from k=1 to k=3. At k=5, I expect little change or a slight drop because the prompts are longer and can contain more irrelevant text.
