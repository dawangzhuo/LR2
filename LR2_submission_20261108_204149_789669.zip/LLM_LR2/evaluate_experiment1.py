﻿import csv
import json
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent
run = root / "results/experiment1"
labels = ("SUPPORT", "CONTRADICT", "NOINFO")
modes = ("llm_only", "rag", "oracle")


def read_jsonl(path):
    with path.open(encoding="utf-8-sig") as file:
        return [json.loads(line) for line in file if line.strip()]


def save_csv(name, rows):
    with (run / name).open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


manifest = json.loads(
    (root / "data/processed/scifact_manifest.json").read_text(encoding="utf-8")
)
dev_ids = manifest["dev_ids"]
dev_set = set(dev_ids)
gold = {}
for row in read_jsonl(root / "data/raw/claims_dev.jsonl"):
    if row["id"] not in dev_set:
        continue
    evidence = row["evidence"]
    found_labels = {
        group["label"] for groups in evidence.values() for group in groups
    }
    if evidence and (len(found_labels) != 1 or not found_labels <= set(labels[:2])):
        raise SystemExit(f"Invalid gold evidence for claim {row['id']}")
    gold[row["id"]] = {
        "label": next(iter(found_labels)) if evidence else "NOINFO",
        "evidence": evidence,
    }

if set(gold) != dev_set or Counter(x["label"] for x in gold.values()) != dict.fromkeys(labels, 30):
    raise SystemExit("Gold dev coverage: FAIL")

evidence_ids = [cid for cid in dev_ids if gold[cid]["label"] != "NOINFO"]
records = read_jsonl(run / "results.jsonl")
by_key = {(row["mode"], row["claim_id"]): row for row in records}
expected = {
    (mode, cid)
    for mode in modes
    for cid in (evidence_ids if mode == "oracle" else dev_ids)
}
if len(records) != 240 or len(by_key) != 240 or set(by_key) != expected:
    raise SystemExit("Experiment 1 record coverage: FAIL")
print("Experiment 1 record coverage: PASS")


def correct(mode, cid):
    row = by_key[mode, cid]
    return row["status"] == "ok" and row["answer"]["label"] == gold[cid]["label"]


def correct_citation(mode, cid):
    # 标签正确，且引用包含同一文档中至少一组完整标准证据。
    if not correct(mode, cid):
        return False
    answer = by_key[mode, cid]["answer"]
    cited = set(answer["sentences"])
    groups = gold[cid]["evidence"].get(answer["doc_id"], [])
    return any(group["sentences"] and set(group["sentences"]) <= cited for group in groups)


summary = []
for subset, ids, selected_modes in (
    ("dev90", dev_ids, modes[:2]),
    ("evidence60", evidence_ids, modes),
):
    print(f"\nSubset: {subset}")
    for mode in selected_modes:
        n_correct = sum(correct(mode, cid) for cid in ids)
        row = {
            "subset": subset,
            "mode": mode,
            "claims": len(ids),
            "correct": n_correct,
            "accuracy": n_correct / len(ids),
            "errors": sum(by_key[mode, cid]["status"] != "ok" for cid in ids),
        }
        for label in labels:
            group = [cid for cid in ids if gold[cid]["label"] == label]
            row[f"recall_{label.lower()}"] = (
                sum(correct(mode, cid) for cid in group) / len(group) if group else None
            )
        citation_ids = [cid for cid in ids if gold[cid]["label"] != "NOINFO"]
        row["correct_citation_rate"] = (
            sum(correct_citation(mode, cid) for cid in citation_ids) / len(citation_ids)
            if mode != "llm_only" else None
        )
        summary.append(row)
        print(f"{mode}: {n_correct}/{len(ids)} = {row['accuracy']:.2%}, errors={row['errors']}")
        for label in labels:
            recall = row[f"recall_{label.lower()}"]
            if recall is not None:
                print(f"  Recall {label}: {recall:.2%}")
        if row["correct_citation_rate"] is not None:
            print(f"  Correct citations: {row['correct_citation_rate']:.2%}")

pairs = []
for cid in dev_ids:
    before = correct("llm_only", cid)
    after = correct("rag", cid)
    pairs.append({
        "claim_id": cid,
        "gold_label": gold[cid]["label"],
        "llm_only_correct": before,
        "rag_k3_correct": after,
        "transition": {
            (False, True): "fixed",
            (True, False): "regressed",
            (True, True): "both_correct",
            (False, False): "both_wrong",
        }[before, after],
    })
counts = Counter(row["transition"] for row in pairs)
print("\nLLM-only -> RAG k=3 on dev90")
for key in ("fixed", "regressed", "both_correct", "both_wrong"):
    print(f"  {key}: {counts[key]}")

failures = [
    {
        "mode": row["mode"],
        "claim_id": row["claim_id"],
        "error": row.get("error", ""),
        "raw_answer": row.get("raw_answer"),
    }
    for row in records if row["status"] != "ok"
]
print("\nRecorded errors")
for (mode, reason), count in sorted(
    Counter((row["mode"], row["error"]) for row in failures).items()
):
    print(f"  {mode}: {count} x {reason}")

save_csv("metrics.csv", summary)
save_csv("paired_transitions.csv", pairs)
(run / "error_details.json").write_text(
    json.dumps(failures, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print("\nExperiment 1 evaluation: PASS")
